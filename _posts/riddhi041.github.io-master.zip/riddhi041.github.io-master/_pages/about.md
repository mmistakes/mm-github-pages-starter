---
permalink: /about/
title: "About"
---

I am a first year student at the Indian Institute of Management, Indore. Mechanical Engineer by heart, Go! SRM. I am a Native of Vadodara, upskilled in Chennai, and grounded in Mumbai while working for the Automobile Giant Hyundai. I love adventures and am passionate about travelling and experiencing new cultures.

Women have made great strides in the pursuit of making this world a better place to live in, my fight is to become one among them. 
