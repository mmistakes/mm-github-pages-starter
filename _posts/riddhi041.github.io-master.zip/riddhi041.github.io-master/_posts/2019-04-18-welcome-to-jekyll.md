---
title: "Welcome to Blog Soldier!"
date: 2020-04-20
categories:
  - blog
tags:
  - Blog Soldier
---

## Lockdown Diaries
Namaste Darshako! Here goes my first blog, things I do during lockdown
1. Think about eating 24x7 and then worry about weight gain
2. Plan to watch something interesting on Netflix, but get frustrated browsing and give up
3. Follow other members of family like a puppy
4. Fight with my brother and go on a shouting spree
5. Pick up a book to read and fall asleep
6. Watch one superhero movie per day
7. Keep checking my phone each second 

The past few days have made me realise that humans can not exist without interacting with fellow humans ! 


Check out my other blogs
